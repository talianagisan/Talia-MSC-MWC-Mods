﻿using MSCLoader;
using UnityEngine;
using HutongGames.PlayMaker;

public class WaterTriggerScript : MonoBehaviour
{
    public float WaterLevel;
    public GameObject Canteen;
    public AudioSource CanteenSoundSource;
    public bool Pause;
    public FsmFloat Thirst;

    // Use this for initialization
    void Start()
    {
        
        Thirst = PlayMakerGlobals.Instance.Variables.FindFsmFloat("PlayerThirst");

        CanteenSoundSource = GetComponent<AudioSource>();
       
        gameObject.transform.localPosition = new Vector3(0f, 0f, 0f);
        gameObject.transform.localRotation = Quaternion.Euler(0f, 0f, 0f);
        gameObject.transform.localScale = new Vector3(1f, 1f, 1f);
        CanteenSoundSource = gameObject.GetComponent<AudioSource>();
        CanteenSoundSource.Stop();

        
        
        
    }

    // Update is called once per frame
    void Update()
    {

        if (cInput.GetButtonUp("Use")) ;
        {
            Pause = false;   
        }

        if (cInput.GetButtonDown("Use"))
        {
            RaycastHit[] hits = Physics.RaycastAll(Camera.main.ScreenPointToRay(Input.mousePosition), 1.0f);
            for (int i = 0; i < hits.Length; ++i)
            {
                if (hits[i].collider.transform.gameObject.name == "Water Canteen(itemx)" && Pause == false && WaterLevel > 0)
                {
                    if (CanteenSoundSource.isPlaying)
                        CanteenSoundSource.Stop();
                    CanteenSoundSource.Play();
                    WaterLevel -= 1f;
                    Pause = true;
                    Thirst.Value -= 4.5f;
                }
            }
        }       
    }
    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.name == "YARD/Building/KITCHEN/kitchen_sink")
        {
            WaterLevel = 7;
        }
    }
}
