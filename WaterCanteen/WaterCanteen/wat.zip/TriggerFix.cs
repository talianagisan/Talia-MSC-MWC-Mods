﻿using UnityEngine;
using System.Collections;
using HutongGames.PlayMaker;

public class TriggerFix : MonoBehaviour
{
    public WaterTriggerScript triggerScript;
    // Use this for initialization
    void Start()
    {

        WaterTriggerScript triggerScript = GetComponent<WaterTriggerScript>();
    }

    // Update is called once per frame
    void Update()
    {
    }

    void OnTriggerStay(Collision other)
    {
        if (other.gameObject.name == "WaterTap")
        {
            triggerScript.WaterLevel = 7;
        }
    }
}
